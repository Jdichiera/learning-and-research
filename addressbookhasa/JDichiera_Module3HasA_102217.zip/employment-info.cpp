#include "employment-info.h"

void EmploymentInfo::setEmployerName(std::string newEmployerName)
{
	employerName = newEmployerName;
}
std::string EmploymentInfo::getEmployerName()
{
	return employerName;
}
