/*
* File:   record.h
* Author: Jeramy Dichiera
*
* Created on October 7, 2017, 12:07 PM
*/
#ifndef RECORD_H
#define RECORD_H
#include"personal-info.h"
#include "employment-info.h"
class Record {
public:
	Record();
	Record(int newRecordNumber, std::string newFirstName, std::string newLastName,
		int newAge, std::string newTelephoneNumber, std::string newEmployerName);
	int getRecordNumber();

	void printRecord();
	void updateFirstName(std::string newFirstName);
	void updateLastName(std::string newLastName);
	void updateAge(int newAge);
	void updateTelephonenumber(std::string newTelephonenumber);
	void updateEmployer(std::string newEmployer);

private:
	int recordNumber;
	PersonalInfo personalInfo;
	EmploymentInfo employmentInfo;
	
};


#endif /* RECORD_H */

